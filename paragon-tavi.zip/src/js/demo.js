const demo = () => console.log('%c Tavi v1.0.0 - by Emkalab.dev! ', 'background: #222; color: #fff');
demo()
