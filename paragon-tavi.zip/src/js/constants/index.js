class Constants {
  static ANTD = {
    MESSAGE: {
      SUCCESS: 'success',
      ERROR: 'error',
      WARNING: 'warning'

    }
  };
}

export default Constants
