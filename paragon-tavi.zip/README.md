# Webpack 5 Boilerplate Tailwind

![Maintenance](https://img.shields.io/maintenance/No/2021?logo=github)
![webpack-current](https://img.shields.io/badge/webpack-v5.64.0-green?logo=webpack)
